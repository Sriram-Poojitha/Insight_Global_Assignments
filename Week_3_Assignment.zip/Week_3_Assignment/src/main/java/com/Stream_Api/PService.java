package com.Stream_Api;



import java.time.LocalDate;
import java.util.Arrays;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

class Product{
	  public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public Double getQty() {
		return qty;
	}
	public void setQty(Double qty) {
		this.qty = qty;
	}
	public Double getPrice() {
		return price;
	}
	public void setPrice(Double price) {
		this.price = price;
	}
	public LocalDate getExpiryDate() {
		return expiryDate;
	}
	public void setExpiryDate(LocalDate expiryDate) {
		this.expiryDate = expiryDate;
	}
	public Supplier getSupplier() {
		return supplier;
	}
	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}
	Integer id;
	  public Product(Integer id, String name, String type, Double qty, Double price, LocalDate expiryDate,
			Supplier supplier) {
		super();
		this.id = id;
		this.name = name;
		this.type = type;
		this.qty = qty;
		this.price = price;
		this.expiryDate = expiryDate;
		this.supplier = supplier;
	}
	String name;
	  @Override
	public String toString() {
		return "Product [id=" + id + ", name=" + name + ", type=" + type + ", qty=" + qty + ", price=" + price
				+ ", expiryDate=" + expiryDate + ", supplier=" + supplier + "]";
	}
	String type;  //ex dairy,pulses,spices,oils,snacks
	  Double qty;
	  Double price;
	  LocalDate  expiryDate;
	  Supplier  supplier;
	}



	class Supplier {
	 Integer id;
	 @Override
	public String toString() {
		return "Supplier [id=" + id + ", sname=" + sname + "]";
	}
	String sname;
	 public Supplier(Integer id, String sname) {
		super();
		this.id = id;
		this.sname = sname;
	}
	
	 public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getSname() {
		return sname;
	}
	public void setSname(String sname) {
		this.sname = sname;
	}
	
	 }


	class PService{  //implement below operations using stream api.
		public static void main(String []args) {
			Supplier supplier1 = new Supplier(1, "SupplierA");
			Supplier supplier2 = new Supplier(2, "SupplierB");

			List<Product> products = Arrays.asList(
					new Product(1, "Milk", "Dairy", 1.0, 50.0, LocalDate.now().plusDays(5), supplier1),
					new Product(2, "Rice", "Pulses", 5.0, 200.0, LocalDate.now().plusDays(15), supplier2),
					new Product(3, "Chili Powder", "Spices", 0.5, 75.0, LocalDate.now().minusDays(2), supplier1),
					new Product(4, "Sunflower Oil", "Oils", 1.0, 150.0, LocalDate.now().plusDays(8), supplier2),
					new Product(5, "Cookies", "Snacks", 2.0, 120.0, LocalDate.now().minusDays(1), supplier1)
					);
			// list Highest priced product
			System.out.println(products.stream().max(Comparator.comparing(Product::getPrice)).orElse(null));
			System.out.println("=====");
			
			// list lowest priced product
			System.out.println(products.stream().min(Comparator.comparing(Product::getPrice)).orElse(null));
			System.out.println("=====");

			//list  product that already expired
			System.out.println(products.stream().filter(p -> p.getExpiryDate().isAfter(LocalDate.now()) && p.getExpiryDate().isBefore(LocalDate.now().plusDays(10))).map(Product::getName).collect(Collectors.toList()));
			System.out.println("=====");
			//list product names list that will expire in next 10 days
			System.out.println(products.stream().filter(p -> p.getExpiryDate().isAfter(LocalDate.now()) && p.getExpiryDate().isBefore(LocalDate.now().plusDays(10))).map(Product::getName).collect(Collectors.toList()));
			System.out.println("=====");
			// display count of  products of different types
			System.out.println(products.stream().collect(Collectors.groupingBy(Product::getType, Collectors.counting())));
			System.out.println("=====");
			// display count of products based on Supplier name.
			System.out.println(products.stream().collect(Collectors.groupingBy(p -> p.getSupplier().getSname(), Collectors.counting())));
			
			

		}
	}



