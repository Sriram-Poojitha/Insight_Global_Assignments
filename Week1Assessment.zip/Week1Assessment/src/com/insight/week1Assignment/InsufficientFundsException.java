package com.insight.week1Assignment;

public class InsufficientFundsException extends Exception {
	 public InsufficientFundsException(String message) {
	 super(message);
	 }
}

