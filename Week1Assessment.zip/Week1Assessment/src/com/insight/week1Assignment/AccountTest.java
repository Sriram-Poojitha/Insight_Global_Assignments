
package com.insight.week1Assignment;

import com.insight.week1Assignment.*;
import java.util.ArrayList;
import java.util.List;


public class AccountTest {
 public static void main(String[] args) {
	 List<Account> accounts = new ArrayList<>();
	 try {
		 Account acc1 = new Account(12345, "Poojitha", AccountType.SAVINGS, 1500.0f);
		 Account acc2 = new Account(67890, "Akanksha", AccountType.CURRENT, 6000.0f);
		 Account acc3 = new Account(11223, "Bhavya", AccountType.SAVINGS, 1200.0f);
		 Account acc4 = new Account(44556, "Farha", AccountType.CURRENT, 5500.0f);
		 Account acc5 = new Account(77889, "Chaithu", AccountType.SAVINGS, 2000.0f);


		 accounts.add(acc1);
		 accounts.add(acc2);
		 accounts.add(acc3);
		 accounts.add(acc4);
		 accounts.add(acc5);
	 }
	 catch (InvalidAmountException | LowBalanceException e) {
		 System.err.println("Error creating account: " + e.getMessage());
		 return; 
	 }


	 AccountService accountService = new AccountService(accounts);


	 try {
		 accountService.deposit(12345, 500.0f);
	 } catch (InvalidAmountException | AccountNotFoundException e) {
		 System.err.println("Deposit error: " + e.getMessage());
	 }


 
	 try {
		 accountService.withdraw(67890, 1000.0f);
	 } catch (InvalidAmountException | InsufficientFundsException | AccountNotFoundException e) {
		 System.err.println("Withdrawal error: " + e.getMessage());
	 }



	 try {
		 float balance = accountService.getBalance(11223);
		 System.out.println("Balance for account 11223: " + balance);
	 } catch (AccountNotFoundException e) {
		 System.err.println("GetBalance error: " + e.getMessage());
	 }

	 try {
		 boolean isValid = accountService.isValidAccount(44556);
		 System.out.println("Is account 44556 valid? " + isValid);
	 } catch (AccountNotFoundException e) {
		 System.err.println("IsValidAccount error: " + e.getMessage());
	 }

	 try {
		 accountService.isValidAccount(99999);
	 } catch (AccountNotFoundException e) {
		 System.err.println("IsValidAccount error: " + e.getMessage());
	 }


	 try {
		 new Account(98765, "Test User", AccountType.SAVINGS, 500.0f);
	 } catch (InvalidAmountException | LowBalanceException e) {
		 System.err.println("Error creating account: " + e.getMessage());
	 }
 }
}
