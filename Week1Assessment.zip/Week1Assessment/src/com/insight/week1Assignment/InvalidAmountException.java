package com.insight.week1Assignment;



public class InvalidAmountException extends Exception {
	public InvalidAmountException(String message) {
		super(message);
	}
}