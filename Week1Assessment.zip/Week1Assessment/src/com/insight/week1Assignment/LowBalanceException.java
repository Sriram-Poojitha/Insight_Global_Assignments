package com.insight.week1Assignment;

public class LowBalanceException extends Exception {
	 public LowBalanceException(String message) {
	 super(message);
	 }
	}