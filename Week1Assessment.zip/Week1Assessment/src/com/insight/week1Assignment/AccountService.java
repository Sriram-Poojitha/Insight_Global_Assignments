package com.insight.week1Assignment;


import com.insight.week1Assignment.*;

import java.util.ArrayList;
import java.util.List;


public class AccountService {


	private List<Account> accountList = new ArrayList<>();
	public AccountService() {
 
	}


	public AccountService(List<Account> accountList) {
		this.accountList = accountList;
	}


	public boolean isValidAccount(int accNumber) throws AccountNotFoundException {
		for (Account account : accountList) {
			if (account.getAccNumber() == accNumber) {
				return true; // Account found
			}
		}
		throw new AccountNotFoundException("Account with number " + accNumber + " not found.");
	}


	public void deposit(int accNumber, float amt) throws InvalidAmountException, AccountNotFoundException {
		if (amt <= 0) {
			throw new InvalidAmountException("Deposit amount must be positive.");
		}


		Account account = findAccount(accNumber);
		if (account != null) {
			account.setBalance(account.getBalance() + amt);
			System.out.println("Deposit successful. New balance: " + account.getBalance());
		}
		else {
			throw new AccountNotFoundException("Account not found.");
		}
	}


	public void withdraw(int accNumber, float amt) throws InvalidAmountException, InsufficientFundsException, AccountNotFoundException {
		if (amt < 500) {
			throw new InvalidAmountException("Minimum withdrawal amount is 500.");
		}


		Account account = findAccount(accNumber);
		if (account != null) {
			float currentBalance = account.getBalance();


			float minBalance = (account.getType() == AccountType.SAVINGS) ? 1000 : 5000;


			if (currentBalance - amt < minBalance) {
				throw new InsufficientFundsException("Insufficient funds. Minimum balance of " + minBalance + " must be maintained.");
			}


			account.setBalance(currentBalance - amt);
			System.out.println("Withdrawal successful. New balance: " + account.getBalance());
		}
		else {
			throw new AccountNotFoundException("Account not found.");
		}
	}


	public float getBalance(int accNumber) throws AccountNotFoundException {
		Account account = findAccount(accNumber);
		if (account != null) {
			return account.getBalance();
		}
		else {
			throw new AccountNotFoundException("Account not found.");
		}
	}


	private Account findAccount(int accNumber) {
		for (Account account : accountList) {
			if (account.getAccNumber().equals(accNumber)) {
				return account;
			}
		}
		return null;
	}


	public List<Account> getAccountList() {
		return accountList;
	}


	public void setAccountList(List<Account> accountList) {
		this.accountList = accountList;
	}
}
