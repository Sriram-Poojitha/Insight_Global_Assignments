package com.insight.week1Assignment;

public enum AccountType {
	 SAVINGS,
	 CURRENT
	}
